<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('names')); ?>

            <?php echo e(Form::text('names', $administrator->names, ['class' => 'form-control' . ($errors->has('names') ? ' is-invalid' : ''), 'placeholder' => 'Names'])); ?>

            <?php echo $errors->first('names', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('lastnames')); ?>

            <?php echo e(Form::text('lastnames', $administrator->lastnames, ['class' => 'form-control' . ($errors->has('lastnames') ? ' is-invalid' : ''), 'placeholder' => 'Lastnames'])); ?>

            <?php echo $errors->first('lastnames', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('birthdate')); ?>

            <?php echo e(Form::text('birthdate', $administrator->birthdate, ['class' => 'form-control' . ($errors->has('birthdate') ? ' is-invalid' : ''), 'placeholder' => 'Birthdate'])); ?>

            <?php echo $errors->first('birthdate', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tecnoschool\resources\views/administrator/form.blade.php ENDPATH**/ ?>